﻿using BookExchange.API.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BookExchange.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoriesController : ControllerBase
    {
        private readonly BookExchangeDbContext _context;

        public CategoriesController(BookExchangeDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetCategories()
        {
            var categories = await _context.Categories
                .Where(c => c.IsActive)
                .Select(c => new
                {
                    c.Id,
                    c.Name,
                    c.Description,
                    c.IconUrl,
                    BookCount = c.Books.Count(b => b.Status == Models.BookStatus.Available),
                    Subcategories = c.Subcategories
                        .Where(s => s.IsActive)
                        .Select(s => new
                        {
                            s.Id,
                            s.Name,
                            s.Description,
                            BookCount = s.Books.Count(b => b.Status == Models.BookStatus.Available)
                        })
                        .ToList()
                })
                .ToListAsync();

            return Ok(categories);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetCategory(int id)
        {
            var category = await _context.Categories
                .Include(c => c.Subcategories)
                .FirstOrDefaultAsync(c => c.Id == id && c.IsActive);

            if (category == null)
                return NotFound();

            var result = new
            {
                category.Id,
                category.Name,
                category.Description,
                category.IconUrl,
                BookCount = await _context.Books.CountAsync(b => b.CategoryId == id && b.Status == Models.BookStatus.Available),
                Subcategories = category.Subcategories
                    .Where(s => s.IsActive)
                    .Select(s => new
                    {
                        s.Id,
                        s.Name,
                        s.Description,
                        BookCount = _context.Books.Count(b => b.SubcategoryId == s.Id && b.Status == Models.BookStatus.Available)
                    })
                    .ToList()
            };

            return Ok(result);
        }
    }
}