﻿using BookExchange.API.DTOs;
using BookExchange.API.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace BookExchange.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BooksController : ControllerBase
    {
        private readonly IBookService _bookService;

        public BooksController(IBookService bookService)
        {
            _bookService = bookService;
        }

        [HttpGet]
        public async Task<IActionResult> SearchBooks([FromQuery] BookSearchDto searchDto)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var result = await _bookService.SearchBooksAsync(searchDto, userId);
            return Ok(result);
        }

        [HttpGet("featured")]
        public async Task<IActionResult> GetFeaturedBooks()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var books = await _bookService.GetFeaturedBooksAsync(userId);
            return Ok(books);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetBook(int id)
        {
            try
            {
                var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
                var book = await _bookService.GetBookByIdAsync(id, userId);

                // Increment view count (fire and forget)
                _ = Task.Run(() => _bookService.IncrementViewCountAsync(id));

                return Ok(book);
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { message = ex.Message });
            }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> CreateBook([FromBody] CreateBookDto createBookDto)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            try
            {
                var book = await _bookService.CreateBookAsync(createBookDto, userId);
                return CreatedAtAction(nameof(GetBook), new { id = book.Id }, book);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpPut("{id}")]
        [Authorize]
        public async Task<IActionResult> UpdateBook(int id, [FromBody] UpdateBookDto updateBookDto)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            try
            {
                var book = await _bookService.UpdateBookAsync(id, updateBookDto, userId);
                return Ok(book);
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        [Authorize]
        public async Task<IActionResult> DeleteBook(int id)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            try
            {
                await _bookService.DeleteBookAsync(id, userId);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return NotFound(new { message = ex.Message });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { message = ex.Message });
            }
        }

        [HttpGet("seller/{sellerId}")]
        public async Task<IActionResult> GetBooksBySeller(string sellerId)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            var books = await _bookService.GetBooksBySellerAsync(sellerId, userId);
            return Ok(books);
        }

        [HttpPost("{id}/wishlist")]
        [Authorize]
        public async Task<IActionResult> AddToWishlist(int id)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var added = await _bookService.AddToWishlistAsync(id, userId);
            if (added)
                return Ok(new { message = "Added to wishlist" });
            else
                return BadRequest(new { message = "Book already in wishlist" });
        }

        [HttpDelete("{id}/wishlist")]
        [Authorize]
        public async Task<IActionResult> RemoveFromWishlist(int id)
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var removed = await _bookService.RemoveFromWishlistAsync(id, userId);
            if (removed)
                return Ok(new { message = "Removed from wishlist" });
            else
                return BadRequest(new { message = "Book not in wishlist" });
        }

        [HttpGet("wishlist")]
        [Authorize]
        public async Task<IActionResult> GetWishlist()
        {
            var userId = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            if (string.IsNullOrEmpty(userId))
                return Unauthorized();

            var books = await _bookService.GetWishlistAsync(userId);
            return Ok(books);
        }
    }
}