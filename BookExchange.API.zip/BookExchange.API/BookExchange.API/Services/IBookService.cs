﻿using BookExchange.API.DTOs;

namespace BookExchange.API.Services
{
    public interface IBookService
    {
        Task<BookDto> GetBookByIdAsync(int id, string? userId = null);
        Task<BookSearchResultDto> SearchBooksAsync(BookSearchDto searchDto, string? userId = null);
        Task<BookDto> CreateBookAsync(CreateBookDto createBookDto, string sellerId);
        Task<BookDto> UpdateBookAsync(int id, UpdateBookDto updateBookDto, string sellerId);
        Task DeleteBookAsync(int id, string sellerId);
        Task<List<BookDto>> GetBooksBySellerAsync(string sellerId, string? userId = null);
        Task<List<BookDto>> GetFeaturedBooksAsync(string? userId = null);
        Task IncrementViewCountAsync(int bookId);
        Task<bool> AddToWishlistAsync(int bookId, string userId);
        Task<bool> RemoveFromWishlistAsync(int bookId, string userId);
        Task<List<BookDto>> GetWishlistAsync(string userId);
    }
}