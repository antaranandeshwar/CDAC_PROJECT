﻿using AutoMapper;
using BookExchange.API.Data;
using BookExchange.API.DTOs;
using BookExchange.API.Models;
using Microsoft.EntityFrameworkCore;

namespace BookExchange.API.Services
{
    public class CartService : ICartService
    {
        private readonly BookExchangeDbContext _context;
        private readonly IMapper _mapper;

        public CartService(BookExchangeDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<CartDto> GetCartAsync(string userId)
        {
            var cartItems = await _context.CartItems
                .Include(c => c.Book)
                    .ThenInclude(b => b.Seller)
                .Include(c => c.Book)
                    .ThenInclude(b => b.Images)
                .Where(c => c.UserId == userId)
                .OrderByDescending(c => c.CreatedAt)
                .ToListAsync();

            var cartItemDtos = _mapper.Map<List<CartItemDto>>(cartItems);

            var subtotal = cartItemDtos.Where(c => c.IsAvailable).Sum(c => c.TotalPrice);
            var deliveryFee = subtotal > 500 ? 0 : 50;
            var total = subtotal + deliveryFee;

            return new CartDto
            {
                Items = cartItemDtos,
                Subtotal = subtotal,
                DeliveryFee = deliveryFee,
                Total = total,
                TotalItems = cartItemDtos.Count
            };
        }

        public async Task<CartItemDto> AddToCartAsync(string userId, AddToCartDto addToCartDto)
        {
            var book = await _context.Books
                .Include(b => b.Seller)
                .Include(b => b.Images)
                .FirstOrDefaultAsync(b => b.Id == addToCartDto.BookId);

            if (book == null)
                throw new ArgumentException("Book not found");

            if (book.Status != BookStatus.Available)
                throw new InvalidOperationException("Book is not available for purchase");

            if (book.SellerId == userId)
                throw new InvalidOperationException("You cannot add your own book to cart");

            var existingCartItem = await _context.CartItems
                .FirstOrDefaultAsync(c => c.UserId == userId && c.BookId == addToCartDto.BookId);

            if (existingCartItem != null)
            {
                existingCartItem.Quantity += addToCartDto.Quantity;
                await _context.SaveChangesAsync();

                var existingCartItemDto = _mapper.Map<CartItemDto>(existingCartItem);
                existingCartItemDto.BookTitle = book.Title;
                existingCartItemDto.BookAuthor = book.Author;
                existingCartItemDto.BookImageUrl = book.Images.FirstOrDefault(i => i.IsPrimary)?.ImageUrl
                    ?? book.Images.FirstOrDefault()?.ImageUrl;
                existingCartItemDto.BookCondition = book.Condition.ToString();
                existingCartItemDto.BookPrice = book.SellingPrice;
                existingCartItemDto.SellerId = book.SellerId;
                existingCartItemDto.SellerName = $"{book.Seller.FirstName} {book.Seller.LastName}";
                existingCartItemDto.SellerLocation = book.Location;
                existingCartItemDto.TotalPrice = book.SellingPrice * existingCartItem.Quantity;
                existingCartItemDto.IsAvailable = book.Status == BookStatus.Available;

                return existingCartItemDto;
            }

            var cartItem = new CartItem
            {
                UserId = userId,
                BookId = addToCartDto.BookId,
                Quantity = addToCartDto.Quantity,
                CreatedAt = DateTime.UtcNow
            };

            _context.CartItems.Add(cartItem);
            await _context.SaveChangesAsync();

            var cartItemDto = _mapper.Map<CartItemDto>(cartItem);
            cartItemDto.BookTitle = book.Title;
            cartItemDto.BookAuthor = book.Author;
            cartItemDto.BookImageUrl = book.Images.FirstOrDefault(i => i.IsPrimary)?.ImageUrl
                ?? book.Images.FirstOrDefault()?.ImageUrl;
            cartItemDto.BookCondition = book.Condition.ToString();
            cartItemDto.BookPrice = book.SellingPrice;
            cartItemDto.SellerId = book.SellerId;
            cartItemDto.SellerName = $"{book.Seller.FirstName} {book.Seller.LastName}";
            cartItemDto.SellerLocation = book.Location;
            cartItemDto.TotalPrice = book.SellingPrice * cartItem.Quantity;
            cartItemDto.IsAvailable = book.Status == BookStatus.Available;

            return cartItemDto;
        }

        public async Task<CartItemDto> UpdateCartItemAsync(string userId, int cartItemId, UpdateCartItemDto updateCartItemDto)
        {
            var cartItem = await _context.CartItems
                .Include(c => c.Book)
                    .ThenInclude(b => b.Seller)
                .Include(c => c.Book)
                    .ThenInclude(b => b.Images)
                .FirstOrDefaultAsync(c => c.Id == cartItemId && c.UserId == userId);

            if (cartItem == null)
                throw new ArgumentException("Cart item not found");

            cartItem.Quantity = updateCartItemDto.Quantity;
            await _context.SaveChangesAsync();

            return _mapper.Map<CartItemDto>(cartItem);
        }

        public async Task RemoveFromCartAsync(string userId, int cartItemId)
        {
            var cartItem = await _context.CartItems
                .FirstOrDefaultAsync(c => c.Id == cartItemId && c.UserId == userId);

            if (cartItem == null)
                throw new ArgumentException("Cart item not found");

            _context.CartItems.Remove(cartItem);
            await _context.SaveChangesAsync();
        }

        public async Task ClearCartAsync(string userId)
        {
            var cartItems = await _context.CartItems
                .Where(c => c.UserId == userId)
                .ToListAsync();

            _context.CartItems.RemoveRange(cartItems);
            await _context.SaveChangesAsync();
        }

        public async Task<int> GetCartItemCountAsync(string userId)
        {
            return await _context.CartItems
                .Where(c => c.UserId == userId)
                .SumAsync(c => c.Quantity);
        }
    }
}