﻿using BookExchange.API.DTOs;

namespace BookExchange.API.Services
{
    public interface IChatService
    {
        Task<List<ConversationDto>> GetConversationsAsync(string userId);
        Task<ConversationDto> GetOrCreateConversationAsync(CreateConversationDto createConversationDto, string userId);
        Task<List<MessageDto>> GetMessagesAsync(int conversationId, string userId, int page = 1, int pageSize = 50);
        Task<MessageDto> SendMessageAsync(SendMessageDto sendMessageDto, string senderId);
        Task MarkMessagesAsReadAsync(int conversationId, string userId);
        Task<int> GetUnreadMessageCountAsync(string userId);
    }
}