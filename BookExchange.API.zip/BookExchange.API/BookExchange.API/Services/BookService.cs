﻿using AutoMapper;
using BookExchange.API.Data;
using BookExchange.API.DTOs;
using BookExchange.API.Models;
using Microsoft.EntityFrameworkCore;

namespace BookExchange.API.Services
{
    public class BookService : IBookService
    {
        private readonly BookExchangeDbContext _context;
        private readonly IMapper _mapper;

        public BookService(BookExchangeDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<BookDto> GetBookByIdAsync(int id, string? userId = null)
        {
            var book = await _context.Books
                .Include(b => b.Seller)
                .Include(b => b.Category)
                .Include(b => b.Subcategory)
                .Include(b => b.Images)
                .Include(b => b.Tags)
                .FirstOrDefaultAsync(b => b.Id == id);

            if (book == null)
                throw new ArgumentException("Book not found");

            var bookDto = _mapper.Map<BookDto>(book);

            if (!string.IsNullOrEmpty(userId))
            {
                bookDto.IsWishlisted = await _context.Wishlists
                    .AnyAsync(w => w.UserId == userId && w.BookId == id);
            }

            return bookDto;
        }

        public async Task<BookSearchResultDto> SearchBooksAsync(BookSearchDto searchDto, string? userId = null)
        {
            var query = _context.Books
                .Include(b => b.Seller)
                .Include(b => b.Category)
                .Include(b => b.Subcategory)
                .Include(b => b.Images)
                .Include(b => b.Tags)
                .Where(b => b.Status == BookStatus.Available);

            if (!string.IsNullOrWhiteSpace(searchDto.Query))
            {
                var searchTerm = searchDto.Query.ToLower();
                query = query.Where(b =>
                    b.Title.ToLower().Contains(searchTerm) ||
                    b.Author.ToLower().Contains(searchTerm) ||
                    b.Description.ToLower().Contains(searchTerm) ||
                    b.Tags.Any(t => t.Tag.ToLower().Contains(searchTerm)));
            }

            if (searchDto.CategoryId.HasValue)
                query = query.Where(b => b.CategoryId == searchDto.CategoryId);

            if (searchDto.SubcategoryId.HasValue)
                query = query.Where(b => b.SubcategoryId == searchDto.SubcategoryId);

            if (searchDto.MinPrice.HasValue)
                query = query.Where(b => b.SellingPrice >= searchDto.MinPrice);

            if (searchDto.MaxPrice.HasValue)
                query = query.Where(b => b.SellingPrice <= searchDto.MaxPrice);

            if (searchDto.Condition.HasValue)
                query = query.Where(b => (int)b.Condition == searchDto.Condition);

            if (!string.IsNullOrWhiteSpace(searchDto.Location))
                query = query.Where(b => b.Location.ToLower().Contains(searchDto.Location.ToLower()));

            if (!string.IsNullOrWhiteSpace(searchDto.Language))
                query = query.Where(b => b.Language.ToLower() == searchDto.Language.ToLower());

            query = searchDto.SortBy?.ToLower() switch
            {
                "price-low" => query.OrderBy(b => b.SellingPrice),
                "price-high" => query.OrderByDescending(b => b.SellingPrice),
                "newest" => query.OrderByDescending(b => b.CreatedAt),
                "rating" => query.OrderByDescending(b => b.Seller.ReceivedReviews.Average(r => (double?)r.Rating) ?? 0),
                _ => query.OrderByDescending(b => b.CreatedAt)
            };

            var totalCount = await query.CountAsync();
            var totalPages = (int)Math.Ceiling((double)totalCount / searchDto.PageSize);

            var books = await query
                .Skip((searchDto.Page - 1) * searchDto.PageSize)
                .Take(searchDto.PageSize)
                .ToListAsync();

            var bookDtos = _mapper.Map<List<BookDto>>(books);

            if (!string.IsNullOrEmpty(userId))
            {
                var wishlistedBookIds = await _context.Wishlists
                    .Where(w => w.UserId == userId && bookDtos.Select(b => b.Id).Contains(w.BookId))
                    .Select(w => w.BookId)
                    .ToListAsync();

                foreach (var bookDto in bookDtos)
                {
                    bookDto.IsWishlisted = wishlistedBookIds.Contains(bookDto.Id);
                }
            }

            return new BookSearchResultDto
            {
                Books = bookDtos,
                TotalCount = totalCount,
                Page = searchDto.Page,
                PageSize = searchDto.PageSize,
                TotalPages = totalPages
            };
        }

        public async Task<BookDto> CreateBookAsync(CreateBookDto createBookDto, string sellerId)
        {
            var book = _mapper.Map<Book>(createBookDto);
            book.SellerId = sellerId;
            book.CreatedAt = DateTime.UtcNow;

            _context.Books.Add(book);
            await _context.SaveChangesAsync();

            if (createBookDto.Tags != null && createBookDto.Tags.Any())
            {
                var tags = createBookDto.Tags.Select(tag => new BookTag
                {
                    BookId = book.Id,
                    Tag = tag
                }).ToList();

                _context.BookTags.AddRange(tags);
                await _context.SaveChangesAsync();
            }

            return await GetBookByIdAsync(book.Id);
        }

        public async Task<BookDto> UpdateBookAsync(int id, UpdateBookDto updateBookDto, string sellerId)
        {
            var book = await _context.Books
                .Include(b => b.Tags)
                .FirstOrDefaultAsync(b => b.Id == id && b.SellerId == sellerId);

            if (book == null)
                throw new ArgumentException("Book not found or you don't have permission to update it");

            _mapper.Map(updateBookDto, book);
            book.UpdatedAt = DateTime.UtcNow;

            if (updateBookDto.Tags != null)
            {
                // Load tags from DB to delete properly
                var existingTags = await _context.BookTags
                    .Where(t => t.BookId == book.Id)
                    .ToListAsync();

                _context.BookTags.RemoveRange(existingTags);

                var newTags = updateBookDto.Tags.Select(tag => new BookTag
                {
                    BookId = book.Id,
                    Tag = tag
                }).ToList();

                await _context.BookTags.AddRangeAsync(newTags);
            }

            await _context.SaveChangesAsync();
            return await GetBookByIdAsync(book.Id);
        }

        public async Task DeleteBookAsync(int id, string sellerId)
        {
            var book = await _context.Books
                .FirstOrDefaultAsync(b => b.Id == id && b.SellerId == sellerId);

            if (book == null)
                throw new ArgumentException("Book not found or you don't have permission to delete it");

            var hasPendingOrders = await _context.OrderItems
                .Include(oi => oi.Order)
                .AnyAsync(oi => oi.BookId == id &&
                    (oi.Order.Status == OrderStatus.Pending || oi.Order.Status == OrderStatus.Confirmed));

            if (hasPendingOrders)
                throw new InvalidOperationException("Cannot delete book with pending orders");

            _context.Books.Remove(book);
            await _context.SaveChangesAsync();
        }

        public async Task<List<BookDto>> GetBooksBySellerAsync(string sellerId, string? userId = null)
        {
            var books = await _context.Books
                .Include(b => b.Seller)
                .Include(b => b.Category)
                .Include(b => b.Subcategory)
                .Include(b => b.Images)
                .Include(b => b.Tags)
                .Where(b => b.SellerId == sellerId)
                .OrderByDescending(b => b.CreatedAt)
                .ToListAsync();

            var bookDtos = _mapper.Map<List<BookDto>>(books);

            if (!string.IsNullOrEmpty(userId))
            {
                var wishlistedBookIds = await _context.Wishlists
                    .Where(w => w.UserId == userId && bookDtos.Select(b => b.Id).Contains(w.BookId))
                    .Select(w => w.BookId)
                    .ToListAsync();

                foreach (var bookDto in bookDtos)
                {
                    bookDto.IsWishlisted = wishlistedBookIds.Contains(bookDto.Id);
                }
            }

            return bookDtos;
        }

        public async Task<List<BookDto>> GetFeaturedBooksAsync(string? userId = null)
        {
            var books = await _context.Books
                .Include(b => b.Seller)
                .Include(b => b.Category)
                .Include(b => b.Subcategory)
                .Include(b => b.Images)
                .Include(b => b.Tags)
                .Where(b => b.Status == BookStatus.Available)
                .OrderByDescending(b => b.Views)
                .Take(8)
                .ToListAsync();

            var bookDtos = _mapper.Map<List<BookDto>>(books);

            if (!string.IsNullOrEmpty(userId))
            {
                var wishlistedBookIds = await _context.Wishlists
                    .Where(w => w.UserId == userId && bookDtos.Select(b => b.Id).Contains(w.BookId))
                    .Select(w => w.BookId)
                    .ToListAsync();

                foreach (var bookDto in bookDtos)
                {
                    bookDto.IsWishlisted = wishlistedBookIds.Contains(bookDto.Id);
                }
            }

            return bookDtos;
        }

        public async Task IncrementViewCountAsync(int bookId)
        {
            var book = await _context.Books.FindAsync(bookId);
            if (book != null)
            {
                book.Views++;
                await _context.SaveChangesAsync();
            }
        }

        public async Task<bool> AddToWishlistAsync(int bookId, string userId)
        {
            var existingWishlist = await _context.Wishlists
                .FirstOrDefaultAsync(w => w.UserId == userId && w.BookId == bookId);

            if (existingWishlist != null)
                return false;

            var wishlist = new Wishlist
            {
                UserId = userId,
                BookId = bookId,
                CreatedAt = DateTime.UtcNow
            };

            _context.Wishlists.Add(wishlist);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> RemoveFromWishlistAsync(int bookId, string userId)
        {
            var wishlist = await _context.Wishlists
                .FirstOrDefaultAsync(w => w.UserId == userId && w.BookId == bookId);

            if (wishlist == null)
                return false;

            _context.Wishlists.Remove(wishlist);
            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<List<BookDto>> GetWishlistAsync(string userId)
        {
            var wishlistItems = await _context.Wishlists
                .Include(w => w.Book)
                    .ThenInclude(b => b.Seller)
                .Include(w => w.Book)
                    .ThenInclude(b => b.Category)
                .Include(w => w.Book)
                    .ThenInclude(b => b.Subcategory)
                .Include(w => w.Book)
                    .ThenInclude(b => b.Images)
                .Include(w => w.Book)
                    .ThenInclude(b => b.Tags)
                .Where(w => w.UserId == userId)
                .OrderByDescending(w => w.CreatedAt)
                .ToListAsync();

            var bookDtos = _mapper.Map<List<BookDto>>(wishlistItems.Select(w => w.Book));

            foreach (var bookDto in bookDtos)
            {
                bookDto.IsWishlisted = true;
            }

            return bookDtos;
        }
    }
}
