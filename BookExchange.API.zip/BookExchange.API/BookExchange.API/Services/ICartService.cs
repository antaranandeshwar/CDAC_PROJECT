﻿using BookExchange.API.DTOs;

namespace BookExchange.API.Services
{
    public interface ICartService
    {
        Task<CartDto> GetCartAsync(string userId);
        Task<CartItemDto> AddToCartAsync(string userId, AddToCartDto addToCartDto);
        Task<CartItemDto> UpdateCartItemAsync(string userId, int cartItemId, UpdateCartItemDto updateCartItemDto);
        Task RemoveFromCartAsync(string userId, int cartItemId);
        Task ClearCartAsync(string userId);
        Task<int> GetCartItemCountAsync(string userId);
    }
}