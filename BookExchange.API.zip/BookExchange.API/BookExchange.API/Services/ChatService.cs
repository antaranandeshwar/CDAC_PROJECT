﻿using AutoMapper;
using BookExchange.API.Data;
using BookExchange.API.DTOs;
using BookExchange.API.Models;
using Microsoft.EntityFrameworkCore;

namespace BookExchange.API.Services
{
    public class ChatService : IChatService
    {
        private readonly BookExchangeDbContext _context;
        private readonly IMapper _mapper;

        public ChatService(BookExchangeDbContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<ConversationDto>> GetConversationsAsync(string userId)
        {
            var conversations = await _context.Conversations
                .Include(c => c.User1)
                .Include(c => c.User2)
                .Include(c => c.Book)
                .Include(c => c.Messages.OrderByDescending(m => m.CreatedAt).Take(1))
                .Where(c => c.User1Id == userId || c.User2Id == userId)
                .OrderByDescending(c => c.LastMessageAt ?? c.CreatedAt)
                .ToListAsync();

            var conversationDtos = new List<ConversationDto>();

            foreach (var conversation in conversations)
            {
                var otherUser = conversation.User1Id == userId ? conversation.User2 : conversation.User1;
                var unreadCount = await _context.Messages
                    .CountAsync(m => m.ConversationId == conversation.Id &&
                                   m.ReceiverId == userId && !m.IsRead);

                var conversationDto = new ConversationDto
                {
                    Id = conversation.Id,
                    User1Id = conversation.User1Id,
                    User1Name = $"{conversation.User1.FirstName} {conversation.User1.LastName}",
                    User2Id = conversation.User2Id,
                    User2Name = $"{conversation.User2.FirstName} {conversation.User2.LastName}",
                    BookId = conversation.BookId,
                    BookTitle = conversation.Book?.Title,
                    BookPrice = conversation.Book?.SellingPrice,
                    CreatedAt = conversation.CreatedAt,
                    LastMessageAt = conversation.LastMessageAt,
                    LastMessage = conversation.Messages.FirstOrDefault()?.Content,
                    UnreadCount = unreadCount,
                    IsOnline = false // You can implement online status tracking
                };

                conversationDtos.Add(conversationDto);
            }

            return conversationDtos;
        }

        public async Task<ConversationDto> GetOrCreateConversationAsync(CreateConversationDto createConversationDto, string userId)
        {
            // Check if conversation already exists
            var existingConversation = await _context.Conversations
                .Include(c => c.User1)
                .Include(c => c.User2)
                .Include(c => c.Book)
                .FirstOrDefaultAsync(c =>
                    (c.User1Id == userId && c.User2Id == createConversationDto.OtherUserId) ||
                    (c.User1Id == createConversationDto.OtherUserId && c.User2Id == userId));

            if (existingConversation != null)
            {
                return _mapper.Map<ConversationDto>(existingConversation);
            }

            // Create new conversation
            var conversation = new Conversation
            {
                User1Id = userId,
                User2Id = createConversationDto.OtherUserId,
                BookId = createConversationDto.BookId,
                CreatedAt = DateTime.UtcNow,
                LastMessageAt = DateTime.UtcNow
            };

            _context.Conversations.Add(conversation);
            await _context.SaveChangesAsync();

            // Send initial message
            var message = new Message
            {
                ConversationId = conversation.Id,
                SenderId = userId,
                ReceiverId = createConversationDto.OtherUserId,
                Content = createConversationDto.InitialMessage,
                Type = MessageType.Text,
                CreatedAt = DateTime.UtcNow
            };

            _context.Messages.Add(message);
            await _context.SaveChangesAsync();

            // Reload conversation with includes
            var newConversation = await _context.Conversations
                .Include(c => c.User1)
                .Include(c => c.User2)
                .Include(c => c.Book)
                .FirstAsync(c => c.Id == conversation.Id);

            return _mapper.Map<ConversationDto>(newConversation);
        }

        public async Task<List<MessageDto>> GetMessagesAsync(int conversationId, string userId, int page = 1, int pageSize = 50)
        {
            // Verify user is part of conversation
            var conversation = await _context.Conversations
                .FirstOrDefaultAsync(c => c.Id == conversationId &&
                    (c.User1Id == userId || c.User2Id == userId));

            if (conversation == null)
                throw new UnauthorizedAccessException("Access denied to this conversation");

            var messages = await _context.Messages
                .Include(m => m.Sender)
                .Where(m => m.ConversationId == conversationId)
                .OrderByDescending(m => m.CreatedAt)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            return _mapper.Map<List<MessageDto>>(messages.OrderBy(m => m.CreatedAt));
        }

        public async Task<MessageDto> SendMessageAsync(SendMessageDto sendMessageDto, string senderId)
        {
            // Get or create conversation
            var conversation = await _context.Conversations
                .FirstOrDefaultAsync(c =>
                    (c.User1Id == senderId && c.User2Id == sendMessageDto.ReceiverId) ||
                    (c.User1Id == sendMessageDto.ReceiverId && c.User2Id == senderId));

            if (conversation == null)
            {
                conversation = new Conversation
                {
                    User1Id = senderId,
                    User2Id = sendMessageDto.ReceiverId,
                    BookId = sendMessageDto.BookId,
                    CreatedAt = DateTime.UtcNow,
                    LastMessageAt = DateTime.UtcNow
                };

                _context.Conversations.Add(conversation);
                await _context.SaveChangesAsync();
            }
            else
            {
                conversation.LastMessageAt = DateTime.UtcNow;
            }

            var message = new Message
            {
                ConversationId = conversation.Id,
                SenderId = senderId,
                ReceiverId = sendMessageDto.ReceiverId,
                Content = sendMessageDto.Content,
                Type = (MessageType)sendMessageDto.Type,
                CreatedAt = DateTime.UtcNow
            };

            _context.Messages.Add(message);
            await _context.SaveChangesAsync();

            // Reload message with sender info
            var messageWithSender = await _context.Messages
                .Include(m => m.Sender)
                .FirstAsync(m => m.Id == message.Id);

            return _mapper.Map<MessageDto>(messageWithSender);
        }

        public async Task MarkMessagesAsReadAsync(int conversationId, string userId)
        {
            var unreadMessages = await _context.Messages
                .Where(m => m.ConversationId == conversationId &&
                           m.ReceiverId == userId && !m.IsRead)
                .ToListAsync();

            foreach (var message in unreadMessages)
            {
                message.IsRead = true;
                message.ReadAt = DateTime.UtcNow;
            }

            await _context.SaveChangesAsync();
        }

        public async Task<int> GetUnreadMessageCountAsync(string userId)
        {
            return await _context.Messages
                .CountAsync(m => m.ReceiverId == userId && !m.IsRead);
        }
    }
}