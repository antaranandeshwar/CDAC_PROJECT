﻿using AutoMapper;
using BookExchange.API.Data;
using BookExchange.API.DTOs;
using BookExchange.API.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace BookExchange.API.Services
{
    public class AuthService : IAuthService
    {
        private readonly UserManager<User> _userManager;
        private readonly SignInManager<User> _signInManager;
        private readonly IConfiguration _configuration;
        private readonly IMapper _mapper;
        private readonly BookExchangeDbContext _context;

        public AuthService(
            UserManager<User> userManager,
            SignInManager<User> signInManager,
            IConfiguration configuration,
            IMapper mapper,
            BookExchangeDbContext context)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _configuration = configuration;
            _mapper = mapper;
            _context = context;
        }

        public async Task<AuthResponseDto> RegisterAsync(RegisterDto registerDto)
        {
            var existingUser = await _userManager.FindByEmailAsync(registerDto.Email);
            if (existingUser != null)
                throw new InvalidOperationException("User with this email already exists");

            var user = new User
            {
                UserName = registerDto.Email,
                Email = registerDto.Email,
                FirstName = registerDto.FirstName,
                LastName = registerDto.LastName,
                PhoneNumber = registerDto.PhoneNumber,
                City = registerDto.City,
                State = registerDto.State,
                Pincode = registerDto.Pincode,
                UserType = (UserType)registerDto.UserType,
                CreatedAt = DateTime.UtcNow
            };

            var result = await _userManager.CreateAsync(user, registerDto.Password);
            if (!result.Succeeded)
                throw new InvalidOperationException(string.Join(", ", result.Errors.Select(e => e.Description)));

            var token = GenerateJwtToken(user);
            var userDto = await GetUserDtoAsync(user);

            return new AuthResponseDto
            {
                Token = token,
                Expiration = DateTime.UtcNow.AddDays(7),
                User = userDto
            };
        }

        public async Task<AuthResponseDto> LoginAsync(LoginDto loginDto)
        {
            var user = await _userManager.FindByEmailAsync(loginDto.Email);
            if (user == null)
                throw new UnauthorizedAccessException("Invalid email or password");

            var result = await _signInManager.CheckPasswordSignInAsync(user, loginDto.Password, false);
            if (!result.Succeeded)
                throw new UnauthorizedAccessException("Invalid email or password");

            user.LastLoginAt = DateTime.UtcNow;
            await _userManager.UpdateAsync(user);

            var token = GenerateJwtToken(user);
            var userDto = await GetUserDtoAsync(user);

            return new AuthResponseDto
            {
                Token = token,
                Expiration = DateTime.UtcNow.AddDays(7),
                User = userDto
            };
        }

        public async Task<UserDto> GetUserByIdAsync(string userId)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
                throw new ArgumentException("User not found");

            return await GetUserDtoAsync(user);
        }

        public async Task<UserDto> UpdateUserAsync(string userId, UpdateUserDto updateUserDto)
        {
            var user = await _userManager.FindByIdAsync(userId);
            if (user == null)
                throw new ArgumentException("User not found");

            if (!string.IsNullOrWhiteSpace(updateUserDto.FirstName))
                user.FirstName = updateUserDto.FirstName;

            if (!string.IsNullOrWhiteSpace(updateUserDto.LastName))
                user.LastName = updateUserDto.LastName;

            if (!string.IsNullOrWhiteSpace(updateUserDto.PhoneNumber))
                user.PhoneNumber = updateUserDto.PhoneNumber;

            if (!string.IsNullOrWhiteSpace(updateUserDto.City))
                user.City = updateUserDto.City;

            if (!string.IsNullOrWhiteSpace(updateUserDto.State))
                user.State = updateUserDto.State;

            if (!string.IsNullOrWhiteSpace(updateUserDto.Pincode))
                user.Pincode = updateUserDto.Pincode;

            if (!string.IsNullOrWhiteSpace(updateUserDto.Bio))
                user.Bio = updateUserDto.Bio;

            if (updateUserDto.UserType.HasValue)
                user.UserType = (UserType)updateUserDto.UserType.Value;

            var result = await _userManager.UpdateAsync(user);
            if (!result.Succeeded)
                throw new InvalidOperationException(string.Join(", ", result.Errors.Select(e => e.Description)));

            return await GetUserDtoAsync(user);
        }

        public string GenerateJwtToken(User user)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:Key"]!));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new[]
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id),
                new Claim(ClaimTypes.Email, user.Email!),
                new Claim(ClaimTypes.Name, $"{user.FirstName} {user.LastName}"),
                new Claim("user_id", user.Id)
            };

            var token = new JwtSecurityToken(
                issuer: _configuration["Jwt:Issuer"],
                audience: _configuration["Jwt:Audience"],
                claims: claims,
                expires: DateTime.UtcNow.AddDays(7),
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private async Task<UserDto> GetUserDtoAsync(User user)
        {
            var reviewStats = await _context.Reviews
                .Where(r => r.RevieweeId == user.Id)
                .GroupBy(r => r.RevieweeId)
                .Select(g => new { Rating = g.Average(r => r.Rating), Count = g.Count() })
                .FirstOrDefaultAsync();

            var salesCount = await _context.Orders
                .Where(o => o.SellerId == user.Id && o.Status == OrderStatus.Delivered)
                .CountAsync();

            var purchasesCount = await _context.Orders
                .Where(o => o.BuyerId == user.Id && o.Status == OrderStatus.Delivered)
                .CountAsync();

            return new UserDto
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                Email = user.Email!,
                PhoneNumber = user.PhoneNumber,
                City = user.City,
                State = user.State,
                Pincode = user.Pincode,
                Bio = user.Bio,
                ProfileImageUrl = user.ProfileImageUrl,
                UserType = (int)user.UserType,
                IsVerified = user.IsVerified,
                CreatedAt = user.CreatedAt,
                Rating = reviewStats?.Rating ?? 0,
                TotalReviews = reviewStats?.Count ?? 0,
                TotalSales = salesCount,
                TotalPurchases = purchasesCount
            };
        }
    }
}