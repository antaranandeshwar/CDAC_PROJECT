﻿using BookExchange.API.DTOs;
using BookExchange.API.Models;

namespace BookExchange.API.Services
{
    public interface IAuthService
    {
        Task<AuthResponseDto> RegisterAsync(RegisterDto registerDto);
        Task<AuthResponseDto> LoginAsync(LoginDto loginDto);
        Task<UserDto> GetUserByIdAsync(string userId);
        Task<UserDto> UpdateUserAsync(string userId, UpdateUserDto updateUserDto);
        string GenerateJwtToken(User user);
    }

    public class UpdateUserDto
    {
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? PhoneNumber { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Pincode { get; set; }
        public string? Bio { get; set; }
        public int? UserType { get; set; }
    }
}