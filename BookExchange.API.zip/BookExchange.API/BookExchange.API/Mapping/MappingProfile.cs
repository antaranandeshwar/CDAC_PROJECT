﻿using AutoMapper;
using BookExchange.API.DTOs;
using BookExchange.API.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace BookExchange.API.Mapping
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            // User mappings
            CreateMap<User, UserDto>()
                .ForMember(dest => dest.UserType, opt => opt.MapFrom(src => (int)src.UserType));

            // Book mappings
            CreateMap<Book, BookDto>()
                .ForMember(dest => dest.CategoryName, opt => opt.MapFrom(src => src.Category.Name))
                .ForMember(dest => dest.SubcategoryName, opt => opt.MapFrom(src => src.Subcategory != null ? src.Subcategory.Name : null))
                .ForMember(dest => dest.Condition, opt => opt.MapFrom(src => (int)src.Condition))
                .ForMember(dest => dest.ConditionName, opt => opt.MapFrom(src => src.Condition.ToString()))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (int)src.Status))
                .ForMember(dest => dest.SellerName, opt => opt.MapFrom(src => $"{src.Seller.FirstName} {src.Seller.LastName}"))
                .ForMember(dest => dest.SellerRating, opt => opt.MapFrom(src => src.Seller.ReceivedReviews.Any() ? src.Seller.ReceivedReviews.Average(r => r.Rating) : 0))
                .ForMember(dest => dest.Images, opt => opt.MapFrom(src => src.Images.OrderBy(i => i.SortOrder)))
                .ForMember(dest => dest.Tags, opt => opt.MapFrom(src => src.Tags.Select(t => t.Tag).ToList()));

            CreateMap<CreateBookDto, Book>()
                .ForMember(dest => dest.Condition, opt => opt.MapFrom(src => (BookCondition)src.Condition))
                .ForMember(dest => dest.Tags, opt => opt.MapFrom(src =>
                    src.Tags != null
                        ? src.Tags.Select(t => new BookTag { Tag = t }).ToList()
                        : new List<BookTag>()));

            CreateMap<UpdateBookDto, Book>()
                .ForMember(dest => dest.Condition, opt => opt.MapFrom(src => src.Condition.HasValue ? (BookCondition)src.Condition.Value : BookCondition.Good))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.Status.HasValue ? (BookStatus)src.Status.Value : BookStatus.Available))
                .ForMember(dest => dest.Tags, opt => opt.MapFrom(src =>
                    src.Tags != null
                        ? src.Tags.Select(t => new BookTag { Tag = t }).ToList()
                        : new List<BookTag>()))
                .ForAllMembers(opt => opt.Condition((src, dest, srcMember) => srcMember != null));

            CreateMap<BookImage, BookImageDto>();

            // Order mappings
            CreateMap<Order, OrderDto>()
                .ForMember(dest => dest.BuyerName, opt => opt.MapFrom(src => $"{src.Buyer.FirstName} {src.Buyer.LastName}"))
                .ForMember(dest => dest.SellerName, opt => opt.MapFrom(src => $"{src.Seller.FirstName} {src.Seller.LastName}"))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => (int)src.Status))
                .ForMember(dest => dest.StatusName, opt => opt.MapFrom(src => src.Status.ToString()))
                .ForMember(dest => dest.PaymentMethod, opt => opt.MapFrom(src => (int)src.PaymentMethod))
                .ForMember(dest => dest.PaymentMethodName, opt => opt.MapFrom(src => src.PaymentMethod.ToString()))
                .ForMember(dest => dest.PaymentStatus, opt => opt.MapFrom(src => (int)src.PaymentStatus))
                .ForMember(dest => dest.PaymentStatusName, opt => opt.MapFrom(src => src.PaymentStatus.ToString()));

            CreateMap<OrderItem, OrderItemDto>()
                .ForMember(dest => dest.BookTitle, opt => opt.MapFrom(src => src.Book.Title))
                .ForMember(dest => dest.BookAuthor, opt => opt.MapFrom(src => src.Book.Author))
                .ForMember(dest => dest.BookImageUrl, opt => opt.MapFrom(src => src.Book.Images.FirstOrDefault(i => i.IsPrimary) != null ? src.Book.Images.FirstOrDefault(i => i.IsPrimary)!.ImageUrl : src.Book.Images.FirstOrDefault() != null ? src.Book.Images.FirstOrDefault()!.ImageUrl : null));

            // Cart mappings
            CreateMap<CartItem, CartItemDto>()
                .ForMember(dest => dest.BookTitle, opt => opt.MapFrom(src => src.Book.Title))
                .ForMember(dest => dest.BookAuthor, opt => opt.MapFrom(src => src.Book.Author))
                .ForMember(dest => dest.BookImageUrl, opt => opt.MapFrom(src => src.Book.Images.FirstOrDefault(i => i.IsPrimary) != null ? src.Book.Images.FirstOrDefault(i => i.IsPrimary)!.ImageUrl : src.Book.Images.FirstOrDefault() != null ? src.Book.Images.FirstOrDefault()!.ImageUrl : null))
                .ForMember(dest => dest.BookCondition, opt => opt.MapFrom(src => src.Book.Condition.ToString()))
                .ForMember(dest => dest.BookPrice, opt => opt.MapFrom(src => src.Book.SellingPrice))
                .ForMember(dest => dest.SellerId, opt => opt.MapFrom(src => src.Book.SellerId))
                .ForMember(dest => dest.SellerName, opt => opt.MapFrom(src => $"{src.Book.Seller.FirstName} {src.Book.Seller.LastName}"))
                .ForMember(dest => dest.SellerLocation, opt => opt.MapFrom(src => src.Book.Location))
                .ForMember(dest => dest.TotalPrice, opt => opt.MapFrom(src => src.Book.SellingPrice * src.Quantity))
                .ForMember(dest => dest.IsAvailable, opt => opt.MapFrom(src => src.Book.Status == BookStatus.Available));

            // Chat mappings
            CreateMap<Conversation, ConversationDto>()
                .ForMember(dest => dest.User1Name, opt => opt.MapFrom(src => $"{src.User1.FirstName} {src.User1.LastName}"))
                .ForMember(dest => dest.User2Name, opt => opt.MapFrom(src => $"{src.User2.FirstName} {src.User2.LastName}"))
                .ForMember(dest => dest.BookTitle, opt => opt.MapFrom(src => src.Book != null ? src.Book.Title : null))
                .ForMember(dest => dest.BookPrice, opt => opt.MapFrom(src => src.Book != null ? src.Book.SellingPrice : (decimal?)null));

            CreateMap<Message, MessageDto>()
                .ForMember(dest => dest.SenderName, opt => opt.MapFrom(src => $"{src.Sender.FirstName} {src.Sender.LastName}"))
                .ForMember(dest => dest.Type, opt => opt.MapFrom(src => (int)src.Type));
        }
    }
}
