﻿using System.ComponentModel.DataAnnotations;

namespace BookExchange.API.DTOs
{
    public class OrderDto
    {
        public int Id { get; set; }
        public string OrderNumber { get; set; } = string.Empty;
        public string BuyerId { get; set; } = string.Empty;
        public string BuyerName { get; set; } = string.Empty;
        public string SellerId { get; set; } = string.Empty;
        public string SellerName { get; set; } = string.Empty;
        public decimal TotalAmount { get; set; }
        public decimal DeliveryFee { get; set; }
        public int Status { get; set; }
        public string StatusName { get; set; } = string.Empty;
        public int PaymentMethod { get; set; }
        public string PaymentMethodName { get; set; } = string.Empty;
        public int PaymentStatus { get; set; }
        public string PaymentStatusName { get; set; } = string.Empty;
        public string? DeliveryAddress { get; set; }
        public string? DeliveryMethod { get; set; }
        public string? Notes { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public DateTime? DeliveredAt { get; set; }
        public List<OrderItemDto> OrderItems { get; set; } = new List<OrderItemDto>();
    }

    public class OrderItemDto
    {
        public int Id { get; set; }
        public int BookId { get; set; }
        public string BookTitle { get; set; } = string.Empty;
        public string BookAuthor { get; set; } = string.Empty;
        public string? BookImageUrl { get; set; }
        public int Quantity { get; set; }
        public decimal Price { get; set; }
        public decimal TotalPrice { get; set; }
    }

    public class CreateOrderDto
    {
        [Required]
        public List<CreateOrderItemDto> Items { get; set; } = new List<CreateOrderItemDto>();

        [Required]
        [Range(0, 4)]
        public int PaymentMethod { get; set; }

        [StringLength(500)]
        public string? DeliveryAddress { get; set; }

        [StringLength(200)]
        public string? DeliveryMethod { get; set; }

        public string? Notes { get; set; }
    }

    public class CreateOrderItemDto
    {
        [Required]
        public int BookId { get; set; }

        [Required]
        [Range(1, int.MaxValue)]
        public int Quantity { get; set; }
    }

    public class UpdateOrderStatusDto
    {
        [Required]
        [Range(0, 5)]
        public int Status { get; set; }

        public string? Notes { get; set; }
    }
}