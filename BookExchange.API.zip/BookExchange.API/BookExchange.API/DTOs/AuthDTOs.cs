﻿using System.ComponentModel.DataAnnotations;

namespace BookExchange.API.DTOs
{
    public class RegisterDto
    {
        [Required]
        [StringLength(50)]
        public string FirstName { get; set; } = string.Empty;

        [Required]
        [StringLength(50)]
        public string LastName { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        [Phone]
        public string PhoneNumber { get; set; } = string.Empty;

        [Required]
        [StringLength(100, MinimumLength = 6)]
        public string Password { get; set; } = string.Empty;

        [Required]
        [Compare("Password")]
        public string ConfirmPassword { get; set; } = string.Empty;

        public string? City { get; set; }
        public string? State { get; set; }
        public string? Pincode { get; set; }
        public int UserType { get; set; } = 0; // 0 = Buyer, 1 = Seller, 2 = Both
        public List<string>? FavoriteGenres { get; set; }
    }

    public class LoginDto
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string Password { get; set; } = string.Empty;

        public bool RememberMe { get; set; } = false;
    }

    public class AuthResponseDto
    {
        public string Token { get; set; } = string.Empty;
        public DateTime Expiration { get; set; }
        public UserDto User { get; set; } = null!;
    }

    public class UserDto
    {
        public string Id { get; set; } = string.Empty;
        public string FirstName { get; set; } = string.Empty;
        public string LastName { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string? PhoneNumber { get; set; }
        public string? City { get; set; }
        public string? State { get; set; }
        public string? Pincode { get; set; }
        public string? Bio { get; set; }
        public string? ProfileImageUrl { get; set; }
        public int UserType { get; set; }
        public bool IsVerified { get; set; }
        public DateTime CreatedAt { get; set; }
        public double Rating { get; set; }
        public int TotalReviews { get; set; }
        public int TotalSales { get; set; }
        public int TotalPurchases { get; set; }
    }
}