﻿using System.ComponentModel.DataAnnotations;

namespace BookExchange.API.DTOs
{
    public class ConversationDto
    {
        public int Id { get; set; }
        public string User1Id { get; set; } = string.Empty;
        public string User1Name { get; set; } = string.Empty;
        public string User2Id { get; set; } = string.Empty;
        public string User2Name { get; set; } = string.Empty;
        public int? BookId { get; set; }
        public string? BookTitle { get; set; }
        public decimal? BookPrice { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? LastMessageAt { get; set; }
        public string? LastMessage { get; set; }
        public int UnreadCount { get; set; }
        public bool IsOnline { get; set; }
    }

    public class MessageDto
    {
        public int Id { get; set; }
        public int ConversationId { get; set; }
        public string SenderId { get; set; } = string.Empty;
        public string SenderName { get; set; } = string.Empty;
        public string ReceiverId { get; set; } = string.Empty;
        public string Content { get; set; } = string.Empty;
        public int Type { get; set; }
        public bool IsRead { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? ReadAt { get; set; }
    }

    public class SendMessageDto
    {
        [Required]
        public string ReceiverId { get; set; } = string.Empty;

        [Required]
        public string Content { get; set; } = string.Empty;

        public int? BookId { get; set; }

        [Range(0, 3)]
        public int Type { get; set; } = 0; // 0 = Text, 1 = Image, 2 = File, 3 = Location
    }

    public class CreateConversationDto
    {
        [Required]
        public string OtherUserId { get; set; } = string.Empty;

        public int? BookId { get; set; }

        [Required]
        public string InitialMessage { get; set; } = string.Empty;
    }
}