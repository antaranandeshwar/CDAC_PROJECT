﻿using System.ComponentModel.DataAnnotations;

namespace BookExchange.API.DTOs
{
    public class BookDto
    {
        public int Id { get; set; }
        public string Title { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public string? ISBN { get; set; }
        public string? Publisher { get; set; }
        public int? PublishedYear { get; set; }
        public string? Edition { get; set; }
        public string Language { get; set; } = string.Empty;
        public int? Pages { get; set; }
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public int? SubcategoryId { get; set; }
        public string? SubcategoryName { get; set; }
        public int Condition { get; set; }
        public string ConditionName { get; set; } = string.Empty;
        public string? ConditionNotes { get; set; }
        public decimal OriginalPrice { get; set; }
        public decimal SellingPrice { get; set; }
        public bool IsNegotiable { get; set; }
        public string Description { get; set; } = string.Empty;
        public string Location { get; set; } = string.Empty;
        public int Status { get; set; }
        public int Views { get; set; }
        public DateTime CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string SellerId { get; set; } = string.Empty;
        public string SellerName { get; set; } = string.Empty;
        public double SellerRating { get; set; }
        public List<BookImageDto> Images { get; set; } = new List<BookImageDto>();
        public List<string> Tags { get; set; } = new List<string>();
        public bool IsWishlisted { get; set; } = false;
    }

    public class CreateBookDto
    {
        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Author { get; set; } = string.Empty;

        [StringLength(20)]
        public string? ISBN { get; set; }

        [StringLength(100)]
        public string? Publisher { get; set; }

        public int? PublishedYear { get; set; }

        [StringLength(50)]
        public string? Edition { get; set; }

        [Required]
        [StringLength(50)]
        public string Language { get; set; } = "English";

        public int? Pages { get; set; }

        [Required]
        public int CategoryId { get; set; }

        public int? SubcategoryId { get; set; }

        [Required]
        [Range(0, 4)]
        public int Condition { get; set; }

        public string? ConditionNotes { get; set; }

        [Required]
        [Range(0.01, double.MaxValue)]
        public decimal OriginalPrice { get; set; }

        [Required]
        [Range(0.01, double.MaxValue)]
        public decimal SellingPrice { get; set; }

        public bool IsNegotiable { get; set; } = true;

        [Required]
        public string Description { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Location { get; set; } = string.Empty;

        public List<string>? Tags { get; set; }
        public List<string>? MeetupPreferences { get; set; }
    }

    public class UpdateBookDto
    {
        [StringLength(200)]
        public string? Title { get; set; }

        [StringLength(100)]
        public string? Author { get; set; }

        [StringLength(20)]
        public string? ISBN { get; set; }

        [StringLength(100)]
        public string? Publisher { get; set; }

        public int? PublishedYear { get; set; }

        [StringLength(50)]
        public string? Edition { get; set; }

        [StringLength(50)]
        public string? Language { get; set; }

        public int? Pages { get; set; }

        public int? CategoryId { get; set; }

        public int? SubcategoryId { get; set; }

        [Range(0, 4)]
        public int? Condition { get; set; }

        public string? ConditionNotes { get; set; }

        [Range(0.01, double.MaxValue)]
        public decimal? OriginalPrice { get; set; }

        [Range(0.01, double.MaxValue)]
        public decimal? SellingPrice { get; set; }

        public bool? IsNegotiable { get; set; }

        public string? Description { get; set; }

        [StringLength(100)]
        public string? Location { get; set; }

        [Range(0, 3)]
        public int? Status { get; set; }

        public List<string>? Tags { get; set; }
    }

    public class BookImageDto
    {
        public int Id { get; set; }
        public string ImageUrl { get; set; } = string.Empty;
        public string? AltText { get; set; }
        public bool IsPrimary { get; set; }
        public int SortOrder { get; set; }
    }

    public class BookSearchDto
    {
        public string? Query { get; set; }
        public int? CategoryId { get; set; }
        public int? SubcategoryId { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public int? Condition { get; set; }
        public string? Location { get; set; }
        public string? Language { get; set; }
        public string? SortBy { get; set; } = "relevance"; // relevance, price-low, price-high, rating, newest
        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 20;
    }

    public class BookSearchResultDto
    {
        public List<BookDto> Books { get; set; } = new List<BookDto>();
        public int TotalCount { get; set; }
        public int Page { get; set; }
        public int PageSize { get; set; }
        public int TotalPages { get; set; }
    }
}