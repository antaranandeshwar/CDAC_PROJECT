﻿using System.ComponentModel.DataAnnotations;

namespace BookExchange.API.Models
{
    public class BookImage
    {
        public int Id { get; set; }

        public int BookId { get; set; }

        [Required]
        [StringLength(500)]
        public string ImageUrl { get; set; } = string.Empty;

        [StringLength(200)]
        public string? AltText { get; set; }

        public bool IsPrimary { get; set; } = false;

        public int SortOrder { get; set; } = 0;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation property
        public virtual Book Book { get; set; } = null!;
    }

    public class BookTag
    {
        public int Id { get; set; }

        public int BookId { get; set; }

        [Required]
        [StringLength(50)]
        public string Tag { get; set; } = string.Empty;

        // Navigation property
        public virtual Book Book { get; set; } = null!;
    }
}