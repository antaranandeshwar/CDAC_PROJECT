﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookExchange.API.Models
{
    public class Review
    {
        public int Id { get; set; }

        [Required]
        public string ReviewerId { get; set; } = string.Empty;

        [Required]
        public string RevieweeId { get; set; } = string.Empty;

        public int? BookId { get; set; }

        public int? OrderId { get; set; }

        [Range(1, 5)]
        public int Rating { get; set; }

        [StringLength(1000)]
        public string? Comment { get; set; }

        public ReviewType Type { get; set; } = ReviewType.SellerReview;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation properties
        [ForeignKey("ReviewerId")]
        public virtual User Reviewer { get; set; } = null!;

        [ForeignKey("RevieweeId")]
        public virtual User Reviewee { get; set; } = null!;

        public virtual Book? Book { get; set; }
        public virtual Order? Order { get; set; }
    }

    public enum ReviewType
    {
        SellerReview = 0,
        BuyerReview = 1,
        BookReview = 2
    }
}
