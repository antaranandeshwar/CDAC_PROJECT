﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace BookExchange.API.Models
{
    public class Book
    {
        public int Id { get; set; }

        [Required]
        [StringLength(200)]
        public string Title { get; set; } = string.Empty;

        [Required]
        [StringLength(100)]
        public string Author { get; set; } = string.Empty;

        [StringLength(20)]
        public string? ISBN { get; set; }

        [StringLength(100)]
        public string? Publisher { get; set; }

        public int? PublishedYear { get; set; }

        [StringLength(50)]
        public string? Edition { get; set; }

        [Required]
        [StringLength(50)]
        public string Language { get; set; } = "English";

        public int? Pages { get; set; }

        [Required]
        public int CategoryId { get; set; }

        public int? SubcategoryId { get; set; }

        [Required]
        public BookCondition Condition { get; set; }

        public string? ConditionNotes { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal OriginalPrice { get; set; }

        [Required]
        [Column(TypeName = "decimal(10,2)")]
        public decimal SellingPrice { get; set; }

        public bool IsNegotiable { get; set; } = true;

        [Required]
        public string Description { get; set; } = string.Empty;

        [StringLength(100)]
        public string Location { get; set; } = string.Empty;

        public BookStatus Status { get; set; } = BookStatus.Available;

        public int Views { get; set; } = 0;

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? UpdatedAt { get; set; }

        [Required]
        public string SellerId { get; set; } = string.Empty;

        // Navigation properties
        [ForeignKey("SellerId")]
        public virtual User Seller { get; set; } = null!;

        public virtual Category Category { get; set; } = null!;
        public virtual Subcategory? Subcategory { get; set; }
        public virtual ICollection<BookImage> Images { get; set; } = new List<BookImage>();
        public virtual ICollection<BookTag> Tags { get; set; } = new List<BookTag>();
        public virtual ICollection<OrderItem> OrderItems { get; set; } = new List<OrderItem>();
        public virtual ICollection<CartItem> CartItems { get; set; } = new List<CartItem>();
        public virtual ICollection<Wishlist> WishlistItems { get; set; } = new List<Wishlist>();
        public virtual ICollection<Review> Reviews { get; set; } = new List<Review>();
    }

    public enum BookCondition
    {
        LikeNew = 0,
        VeryGood = 1,
        Good = 2,
        Fair = 3,
        Poor = 4
    }

    public enum BookStatus
    {
        Available = 0,
        Sold = 1,
        Reserved = 2,
        Inactive = 3
    }
}