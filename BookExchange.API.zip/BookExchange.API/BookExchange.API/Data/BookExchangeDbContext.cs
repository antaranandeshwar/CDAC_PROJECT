﻿using BookExchange.API.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;

namespace BookExchange.API.Data
{
    public class BookExchangeDbContext : IdentityDbContext<User>
    {
        public BookExchangeDbContext(DbContextOptions<BookExchangeDbContext> options) : base(options)
        {
        }

        public DbSet<Book> Books { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Subcategory> Subcategories { get; set; }
        public DbSet<BookImage> BookImages { get; set; }
        public DbSet<BookTag> BookTags { get; set; }
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<Wishlist> Wishlists { get; set; }
        public DbSet<Conversation> Conversations { get; set; }
        public DbSet<Message> Messages { get; set; }
        public DbSet<Review> Reviews { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            // Configure User relationships
            builder.Entity<User>()
                .HasMany(u => u.Books)
                .WithOne(b => b.Seller)
                .HasForeignKey(b => b.SellerId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure Order relationships
            builder.Entity<Order>()
                .HasOne(o => o.Buyer)
                .WithMany(u => u.BuyerOrders)
                .HasForeignKey(o => o.BuyerId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Order>()
                .HasOne(o => o.Seller)
                .WithMany(u => u.SellerOrders)
                .HasForeignKey(o => o.SellerId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure Message relationships
            builder.Entity<Message>()
                .HasOne(m => m.Sender)
                .WithMany(u => u.SentMessages)
                .HasForeignKey(m => m.SenderId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Message>()
                .HasOne(m => m.Receiver)
                .WithMany(u => u.ReceivedMessages)
                .HasForeignKey(m => m.ReceiverId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure Review relationships
            builder.Entity<Review>()
                .HasOne(r => r.Reviewer)
                .WithMany(u => u.GivenReviews)
                .HasForeignKey(r => r.ReviewerId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Review>()
                .HasOne(r => r.Reviewee)
                .WithMany(u => u.ReceivedReviews)
                .HasForeignKey(r => r.RevieweeId)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure Conversation relationships
            builder.Entity<Conversation>()
                .HasOne(c => c.User1)
                .WithMany()
                .HasForeignKey(c => c.User1Id)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Conversation>()
                .HasOne(c => c.User2)
                .WithMany()
                .HasForeignKey(c => c.User2Id)
                .OnDelete(DeleteBehavior.Restrict);

            // Configure unique constraints
            builder.Entity<CartItem>()
                .HasIndex(c => new { c.UserId, c.BookId })
                .IsUnique();

            builder.Entity<Wishlist>()
                .HasIndex(w => new { w.UserId, w.BookId })
                .IsUnique();

            // Seed data
            SeedData(builder);
        }

        private void SeedData(ModelBuilder builder)
        {
            // Seed Categories
            builder.Entity<Category>().HasData(
                new Category { Id = 1, Name = "Fiction", Description = "Novels, stories, and literary works" },
                new Category { Id = 2, Name = "Non-Fiction", Description = "Real-world topics and factual content" },
                new Category { Id = 3, Name = "Academic", Description = "Educational and academic textbooks" },
                new Category { Id = 4, Name = "Technical", Description = "Programming, engineering, and technical books" },
                new Category { Id = 5, Name = "Business", Description = "Business, management, and entrepreneurship" },
                new Category { Id = 6, Name = "Self-Help", Description = "Personal development and self-improvement" }
            );

            // Seed Subcategories
            builder.Entity<Subcategory>().HasData(
                // Fiction subcategories
                new Subcategory { Id = 1, CategoryId = 1, Name = "Romance" },
                new Subcategory { Id = 2, CategoryId = 1, Name = "Mystery" },
                new Subcategory { Id = 3, CategoryId = 1, Name = "Sci-Fi" },
                new Subcategory { Id = 4, CategoryId = 1, Name = "Fantasy" },

                // Non-Fiction subcategories
                new Subcategory { Id = 5, CategoryId = 2, Name = "Biography" },
                new Subcategory { Id = 6, CategoryId = 2, Name = "History" },
                new Subcategory { Id = 7, CategoryId = 2, Name = "Politics" },

                // Academic subcategories
                new Subcategory { Id = 8, CategoryId = 3, Name = "Engineering" },
                new Subcategory { Id = 9, CategoryId = 3, Name = "Medical" },
                new Subcategory { Id = 10, CategoryId = 3, Name = "Law" },

                // Technical subcategories
                new Subcategory { Id = 11, CategoryId = 4, Name = "Programming" },
                new Subcategory { Id = 12, CategoryId = 4, Name = "Web Development" },
                new Subcategory { Id = 13, CategoryId = 4, Name = "Data Science" },

                // Business subcategories
                new Subcategory { Id = 14, CategoryId = 5, Name = "Management" },
                new Subcategory { Id = 15, CategoryId = 5, Name = "Finance" },
                new Subcategory { Id = 16, CategoryId = 5, Name = "Marketing" },

                // Self-Help subcategories
                new Subcategory { Id = 17, CategoryId = 6, Name = "Personal Development" },
                new Subcategory { Id = 18, CategoryId = 6, Name = "Productivity" },
                new Subcategory { Id = 19, CategoryId = 6, Name = "Health" }
            );
        }
    }
}